# ✦ ATS Resume Optimizer

A Python CLI tool that uses the Anthropic API to analyze your resume against a job description, extract ATS keywords, and generate a tailored, optimized resume — without any browser UI.

---

## What it does

1. **Extracts 15-20 ATS keywords** from the job description (skills, tools, action verbs, qualifications)
2. **Scores keyword overlap** between your profile and the JD
3. **Rewrites your resume** incorporating matched keywords naturally
4. **Flags gaps** — keywords in the JD that your profile doesn't support (honest, no fabrication)
5. **Gives application tips** specific to the role

---

## Project structure

```
ats-resume-optimizer/
├── src/
│   ├── optimizer.py      # Core API logic (shared by both modes)
│   ├── cli.py            # Single resume vs single JD
│   └── batch.py          # One profile vs many JDs
├── inputs/
│   ├── profile.txt           # Your resume/profile (edit this)
│   ├── job_description.txt   # Single JD to target (edit this)
│   └── jobs/                 # Drop multiple JDs here for batch mode
│       └── example_product_analyst.txt
├── outputs/              # Generated results land here (gitignored)
├── requirements.txt
├── .gitignore
└── README.md
```

---

## Setup

### 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/ats-resume-optimizer.git
cd ats-resume-optimizer
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

Or with a virtual environment (recommended):

```bash
python -m venv venv
source venv/bin/activate      # Mac/Linux
venv\Scripts\activate         # Windows

pip install -r requirements.txt
```

### 3. Set your Anthropic API key

```bash
export ANTHROPIC_API_KEY=sk-ant-...        # Mac/Linux
set ANTHROPIC_API_KEY=sk-ant-...           # Windows CMD
$env:ANTHROPIC_API_KEY="sk-ant-..."       # Windows PowerShell
```

Get your key from [console.anthropic.com](https://console.anthropic.com).

**Never commit your API key.** The `.gitignore` already excludes `.env` files.

---

## Usage

### Single mode — one profile vs one JD

```bash
# Edit your profile and JD first
nano inputs/profile.txt
nano inputs/job_description.txt

# Run
cd src
python cli.py --profile ../inputs/profile.txt --jd ../inputs/job_description.txt
```

Output files are saved to `outputs/` automatically:
- `outputs/ats_result_TIMESTAMP.json` — full JSON (score, keywords, resume, tips)
- `outputs/ats_result_TIMESTAMP_resume.txt` — clean resume text ready to paste

Options:
```
--profile PATH      Path to your resume/profile .txt file  (required)
--jd PATH           Path to the job description .txt file  (required)
--output-dir DIR    Where to save results (default: outputs/)
--no-save           Print to terminal only, skip saving
```

### Batch mode — one profile vs many JDs

Drop multiple JD files into `inputs/jobs/`, then:

```bash
cd src
python batch.py --profile ../inputs/profile.txt --jd-dir ../inputs/jobs/
```

Prints a ranked summary table of all JDs by match score, and saves a tailored resume + JSON for each one into `outputs/batch/`.

---

## Output format

The tool saves a JSON file with this structure:

```json
{
  "keywords": {
    "matched": ["financial modeling", "DCF", "Excel"],
    "incorporated": ["financial modeling", "DCF", "Excel", "stakeholder communication"],
    "missing": ["Bloomberg", "LBO", "CFA"]
  },
  "matchScore": 74,
  "resume": "FULL TAILORED RESUME TEXT...",
  "tips": [
    "Highlight your Hex Advisory financial analysis work early in interviews",
    "Address the Bloomberg/FactSet gap — consider getting a trial or noting willingness to learn",
    "Lead with the MiM at ESCP to signal the finance pivot is intentional"
  ]
}
```

---

## Tips for best results

- **Profile file**: paste your full LinkedIn profile text (About + Experience + Education + Skills), or an existing resume. More detail = better tailoring.
- **JD file**: paste the entire job description including responsibilities, requirements, and preferred qualifications. Don't truncate it.
- **Honest gaps**: if the score is under 60%, the JD is asking for things not in your profile. The tool won't invent them — use the gap list to decide if you want to address them in a cover letter.
- **Batch mode**: great for mass-applying — drop 10 JDs in, pick the 3-4 with the highest scores to actually apply to.

---

## Cost

Each run calls `claude-sonnet-4-6` with ~1,000-2,000 tokens in and ~1,500 tokens out.
At current Anthropic pricing that's roughly **$0.01-0.02 per resume**.

---

## License

MIT — use freely, fork it, extend it.

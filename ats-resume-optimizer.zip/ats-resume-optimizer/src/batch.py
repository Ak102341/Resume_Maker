"""
Batch mode: run one profile against multiple job descriptions.

Usage:
    python src/batch.py --profile inputs/profile.txt --jd-dir inputs/jobs/

Reads all .txt files in the jd-dir and produces one output per JD.
Prints a summary table at the end sorted by match score.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from datetime import datetime

from optimizer import load_text, optimize


def main():
    parser = argparse.ArgumentParser(
        description="Batch ATS optimization: one profile vs many JDs"
    )
    parser.add_argument("--profile", required=True, help="Path to your profile/resume text file")
    parser.add_argument("--jd-dir", required=True, help="Directory containing JD .txt files")
    parser.add_argument("--output-dir", default="outputs/batch", help="Where to save results")
    args = parser.parse_args()

    profile_path = Path(args.profile)
    jd_dir = Path(args.jd_dir)
    output_dir = Path(args.output_dir)

    if not profile_path.exists():
        print(f"Error: Profile not found: {profile_path}")
        sys.exit(1)
    if not jd_dir.is_dir():
        print(f"Error: JD directory not found: {jd_dir}")
        sys.exit(1)
    if "ANTHROPIC_API_KEY" not in os.environ:
        print("Error: Set ANTHROPIC_API_KEY first.")
        sys.exit(1)

    jd_files = sorted(jd_dir.glob("*.txt"))
    if not jd_files:
        print(f"No .txt files found in {jd_dir}")
        sys.exit(1)

    print(f"\n✦  ATS Batch Optimizer")
    print(f"   Profile : {profile_path}")
    print(f"   JDs     : {len(jd_files)} files in {jd_dir}\n")

    profile_text = load_text(str(profile_path))
    output_dir.mkdir(parents=True, exist_ok=True)

    summary = []

    for jd_file in jd_files:
        print(f"  Processing: {jd_file.name} ...", end="", flush=True)
        try:
            jd_text = load_text(str(jd_file))
            result = optimize(profile_text, jd_text)
            score = result["matchScore"]

            # Save
            stem = jd_file.stem
            json_path = output_dir / f"{stem}.json"
            txt_path = output_dir / f"{stem}_resume.txt"
            with open(json_path, "w") as f:
                json.dump(result, f, indent=2)
            with open(txt_path, "w") as f:
                f.write(result["resume"])

            summary.append({
                "jd": jd_file.name,
                "score": score,
                "matched": len(result["keywords"].get("incorporated", [])),
                "missing": len(result["keywords"].get("missing", [])),
                "resume": txt_path,
            })
            color = "\033[92m" if score >= 80 else "\033[93m" if score >= 60 else "\033[91m"
            print(f" {color}{score}%\033[0m")

        except Exception as e:
            print(f" ERROR: {e}")
            summary.append({"jd": jd_file.name, "score": -1, "matched": 0, "missing": 0, "resume": None})

    # Summary table
    print("\n" + "=" * 60)
    print(f"  {'JD FILE':<30} {'SCORE':>6}  {'MATCHED':>8}  {'GAPS':>5}")
    print("=" * 60)
    for row in sorted(summary, key=lambda x: x["score"], reverse=True):
        score_str = f"{row['score']}%" if row["score"] >= 0 else "ERROR"
        color = "\033[92m" if row["score"] >= 80 else "\033[93m" if row["score"] >= 60 else "\033[91m"
        print(f"  {row['jd']:<30} {color}{score_str:>6}\033[0m  {row['matched']:>8}  {row['missing']:>5}")
    print("=" * 60)
    print(f"\n  Outputs saved to: {output_dir}/\n")


if __name__ == "__main__":
    main()

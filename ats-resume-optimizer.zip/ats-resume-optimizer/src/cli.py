"""
ATS Resume Optimizer CLI
Usage:
    python src/cli.py --profile inputs/profile.txt --jd inputs/job_description.txt
    python src/cli.py --profile inputs/profile.txt --jd inputs/job_description.txt --output outputs/result.json
"""

import argparse
import json
import os
import sys
from pathlib import Path
from datetime import datetime

from optimizer import load_text, optimize


def print_banner():
    print("\n" + "=" * 60)
    print("  ✦  ATS Resume Optimizer")
    print("=" * 60 + "\n")


def print_result(result: dict):
    score = result["matchScore"]
    color = "\033[92m" if score >= 80 else "\033[93m" if score >= 60 else "\033[91m"
    reset = "\033[0m"

    print(f"  ATS Match Score: {color}{score}%{reset}")
    print(f"  Keywords incorporated: {len(result['keywords'].get('incorporated', []))}")
    print(f"  Keywords missing:      {len(result['keywords'].get('missing', []))}")
    print()

    print("--- INCORPORATED KEYWORDS ---")
    print("  " + ", ".join(result["keywords"].get("incorporated", [])) or "  (none)")
    print()

    print("--- MISSING / GAP KEYWORDS ---")
    missing = result["keywords"].get("missing", [])
    if missing:
        print("  " + ", ".join(missing))
        print("  (These were in the JD but not in your profile)")
    else:
        print("  (None - full coverage!)")
    print()

    print("--- TAILORED RESUME ---")
    print("-" * 60)
    print(result["resume"])
    print("-" * 60)
    print()

    print("--- APPLICATION TIPS ---")
    for i, tip in enumerate(result.get("tips", []), 1):
        print(f"  {i}. {tip}")
    print()


def save_outputs(result: dict, output_dir: Path, base_name: str):
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save full JSON
    json_path = output_dir / f"{base_name}.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    # Save resume as plain text
    txt_path = output_dir / f"{base_name}_resume.txt"
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(result["resume"])

    print(f"  Saved JSON result  -> {json_path}")
    print(f"  Saved resume text  -> {txt_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Optimize your resume for ATS using Claude AI"
    )
    parser.add_argument(
        "--profile", required=True, help="Path to your resume/profile text file"
    )
    parser.add_argument(
        "--jd", required=True, help="Path to the job description text file"
    )
    parser.add_argument(
        "--output-dir",
        default="outputs",
        help="Directory to save results (default: outputs/)",
    )
    parser.add_argument(
        "--no-save", action="store_true", help="Print results only, do not save files"
    )
    args = parser.parse_args()

    print_banner()

    # Validate inputs
    profile_path = Path(args.profile)
    jd_path = Path(args.jd)

    if not profile_path.exists():
        print(f"Error: Profile file not found: {profile_path}")
        sys.exit(1)
    if not jd_path.exists():
        print(f"Error: JD file not found: {jd_path}")
        sys.exit(1)
    if "ANTHROPIC_API_KEY" not in os.environ:
        print("Error: ANTHROPIC_API_KEY environment variable not set.")
        print("  export ANTHROPIC_API_KEY=sk-ant-...")
        sys.exit(1)

    print(f"  Profile : {profile_path}")
    print(f"  JD      : {jd_path}")
    print("\nAnalyzing... (this takes ~10-15 seconds)\n")

    profile_text = load_text(str(profile_path))
    jd_text = load_text(str(jd_path))

    try:
        result = optimize(profile_text, jd_text)
    except Exception as e:
        print(f"Error calling Anthropic API: {e}")
        sys.exit(1)

    print_result(result)

    if not args.no_save:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = f"ats_result_{timestamp}"
        save_outputs(result, Path(args.output_dir), base_name)
        print()


if __name__ == "__main__":
    main()

"""
ATS Resume Optimizer - Core logic
Calls Anthropic API to analyze a resume against a job description.
"""

import os
import json
import anthropic

SYSTEM_PROMPT = """You are an expert ATS resume optimizer and career coach.

Given a candidate's profile/resume and a job description, you will:
1. Extract the top 15-20 ATS keywords from the job description (skills, tools, qualifications, action verbs)
2. Analyze which keywords are already present in the candidate's profile and which are missing
3. Generate a fully ATS-optimized, tailored resume in clean text format

Resume rules:
- Use standard section headers: SUMMARY, EXPERIENCE, EDUCATION, SKILLS, CERTIFICATIONS (only if relevant)
- Incorporate matched keywords naturally throughout -- especially in Summary and Experience bullet points
- Rewrite bullet points using strong action verbs from the JD
- Quantify achievements wherever data exists in the profile
- Keep it to 1 page worth of content (roughly 500-650 words of body text)
- Do NOT fabricate experience or qualifications not present in the profile
- Flag in your keyword analysis which important JD keywords could NOT be incorporated (honest gap analysis)

Respond ONLY in this JSON format (no markdown, no backticks):
{
  "keywords": {
    "matched": ["keyword1", "keyword2"],
    "incorporated": ["keyword1", "keyword2"],
    "missing": ["keyword3", "keyword4"]
  },
  "matchScore": 87,
  "resume": "FULL RESUME TEXT HERE with \\n for newlines",
  "tips": ["tip1", "tip2", "tip3"]
}"""


def load_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()


def optimize(profile_text: str, jd_text: str) -> dict:
    """
    Send profile + JD to Claude, return parsed JSON result.
    Requires ANTHROPIC_API_KEY in environment.
    """
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=2000,
        system=SYSTEM_PROMPT,
        messages=[
            {
                "role": "user",
                "content": (
                    f"CANDIDATE PROFILE / RESUME:\n{profile_text}\n\n"
                    f"---\n\nJOB DESCRIPTION:\n{jd_text}"
                ),
            }
        ],
    )

    raw = message.content[0].text
    return json.loads(raw)
